document.addEventListener("DOMContentLoaded", () => {
    const roomList = document.getElementById("room-list");

    // Placeholder chat rooms (this could be fetched from your Firestore in the future)
    const chatRooms = ["General", "Tech Talk", "Gaming", "Music"];

    // Populate the chat room list
    chatRooms.forEach(room => {
        const listItem = document.createElement("li");
        listItem.textContent = room;
        roomList.appendChild(listItem);
    });
});
